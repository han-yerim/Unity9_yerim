﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        // 델리게이트 선언
        public delegate void EnemyAttackHandler(float damage);

        // 적 클래스
        public class Enemy
        {
            // 공격 이벤트
            public event EnemyAttackHandler OnAttack;

            // 적의 공격 메서드
            public void Attack(float damage)
            {
                // 이벤트 호출
                OnAttack?.Invoke(damage);
                // null 조건부 연산자
                // null 참조가 아닌 경우에만 멤버에 접근하거나 메서드를 호출
            }
        }

        // 플레이어 클래스
        public class Player
        {
            // 플레이어가 받은 데미지 처리 메서드
            public void HandleDamage(float damage)
            {
                // 플레이어의 체력 감소 등의 처리 로직
                Console.WriteLine("플레이어가 {0}의 데미지를 입었습니다.", damage);
                static void Main(string[] args)
                {
                    // 적 객체 생성
                    Enemy enemy = new Enemy();

                    // 플레이어 객체 생성
                    Player player = new Player();

                    // 플레이어의 데미지 처리 메서드를 적의 공격 이벤트에 추가
                    enemy.OnAttack += player.HandleDamage;

                    // 적의 공격
                    enemy.Attack(10.0f);
                }
            }

            string input2 = Console.ReadLine();
            int num2;
            bool isInt2 = int.TryParse(input, out num);


                if (isInt)
                {
                    Console.WriteLine("[보유 골드]");
                    Console.WriteLine("G");
                    Console.WriteLine();
                    Console.WriteLine("[아이템 목록]");
                    Console.WriteLine("- 수련자 갑옷");
                    Console.WriteLine("- 무쇠 갑옷");
                    Console.WriteLine("- 스파르타의 갑옷");
                    Console.WriteLine("- 낡은 검");
                    Console.WriteLine("- 청동 도끼");
                    Console.WriteLine("- 스파르타의 창");
                    Console.WriteLine();
                    Console.WriteLine("1. 아이템 구매");
                    Console.WriteLine("0. 나가기");
                    Console.WriteLine("원하시는 행동을 입력해주세요.");
                    Console.Write(">>");

                    if (num >= 1 && num <= 6)
                    {
                        if (num == 1)
                        {
                            Console.WriteLine("구매를 완료했습니다.");
                        }
                        else
                        {
                            Console.WriteLine("잘못된 입력입니다.");
                        }
}

