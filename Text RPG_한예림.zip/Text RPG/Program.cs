﻿namespace Text_RPG
{
    using System;
    using System.Collections.Generic;
    internal class Program
    {
        public static string UserName;
        public static List<Item> item = new List<Item>(); //아이템 목록
        public static int PlayerGold = 1500; //초기 골드

        static Stack<Action> menuHistory = new Stack<Action>(); //메뉴 접근 기록

        static void Goback() //나가기
        {
            if (menuHistory.Count > 0)
            {
                Action previousMenu = menuHistory.Pop();
                previousMenu.Invoke();
            }
            else
            {
                Console.ReadKey();
            }
        }
        //아이템 장착 관리 클래스
        public interface IUsable
        {
            void Use();
        }

        public class Item : IUsable
        {
            public string Name { get; set; }

            public void Use()
            {
                Console.WriteLine("[E]{0}", Name);
            }
        }

        public class Itemset
        {
            public void UseItem(IUsable item)
            {
                item.Use();
            }
        }
        class GameCharacter
        {
            private Action<float> statsChangedCallback;

            private float stats;

            public float Stats
            {
                get { return stats; }
                set
                {
                    stats = value;
                    statsChangedCallback?.Invoke(stats);
                }
            }

            public void SetStatsChangedCallback(Action<float> callback)
            {
                statsChangedCallback = callback;
            }
        }

        // 상점 시스템 구조체
        struct Player
        {
            public string Name;
            public int Price;
            public string itemInfo;

            public void PrintInfo()
            {
                Console.WriteLine($"{Name} {itemInfo} {Price} G");
            }

            static void Main(string[] args)
            {
                Console.WriteLine("스파르타 던전에 오신 여러분 환영합니다.");
                Console.WriteLine("원하시는 이름을 설정해주세요.");

                UserName = Console.ReadLine();

                Console.WriteLine("안녕하세요, {0}님! 게임을 시작합니다.", UserName);
                Console.WriteLine();
                MainMenu();

                static void Main()
                {
                    MainMenu();
                }

                static void MainMenu()
                {
                    while (true)
                    {
                        Console.WriteLine("스파르타 마을에 오신 여러분 환영합니다.");
                        Console.WriteLine("이곳에서 던전으로 들어가기전 활동을 할 수 있습니다.");
                        Console.WriteLine();

                        Console.WriteLine("1. 상태보기");
                        Console.WriteLine("2. 인벤토리");
                        Console.WriteLine("3. 상점");
                        Console.WriteLine();

                        Console.WriteLine("원하시는 행동을 입력해주세요.");
                        Console.Write(">>");

                        string input = Console.ReadLine();

                        switch (input)
                        {
                            case "1":
                                menuHistory.Push(MainMenu);
                                Stats(input);
                                break;
                            case "2":
                                menuHistory.Push(MainMenu);
                                ItemMenu();
                                break;
                            case "3":
                                menuHistory.Push(MainMenu);
                                ShopMenu();
                                break;
                            default:
                                Console.WriteLine("잘못된 입력입니다.");
                                Console.ReadKey();
                                break;
                        }
                    }
                }

                static void Stats(string input)
                {
                    int num;
                    bool isInt = int.TryParse(input, out num);

                    string user = UserName;
                    int level = 01;
                    int Attack = 10;
                    int Defense = 5;
                    int Health = 100;
                    int Gold = PlayerGold;

                    Console.WriteLine("Lv. {0}", level);
                    Console.WriteLine("{0} ( 전사 )", user);
                    Console.WriteLine("공격력 : {0}", Attack);
                    Console.WriteLine("방어력 : {0}", Defense);
                    Console.WriteLine("체력 : {0}", Health);
                    Console.WriteLine("Gold : {0} G", Gold);
                    Console.WriteLine();

                    Console.WriteLine("0. 나가기");
                    Console.WriteLine();
                    Console.WriteLine("원하시는 행동을 입력해주세요.");
                    Console.Write(">>");
                    string input2 = Console.ReadLine();

                    if (input2 == "0")
                    {
                        Goback();
                        return;
                    }
                }

                static void ItemMenu()
                {
                    while (true)
                    {
                        Player person;
                        Console.WriteLine("[아이템 목록]");
                        Console.WriteLine();
                        Console.WriteLine("1. 장착 관리");
                        Console.WriteLine("0. 나가기");
                        Console.WriteLine();

                        Console.WriteLine("원하시는 행동을 입력해주세요.");
                        Console.Write(">>");
                        string input = Console.ReadLine();

                        if (input == "1")
                        {
                            ItemMenu2();
                        }
                        if (input == "0")
                        {
                            Goback();
                            return;
                        }
                    }
                }

                //아이템 장착 관리
                static void ItemMenu2()
                {
                    Console.WriteLine("[아이템 목록]");
                    Console.WriteLine();

                    Console.WriteLine("0. 나가기");
                    Console.WriteLine("원하시는 행동을 입력해주세요.");
                    Console.Write(">>");
                    string input = Console.ReadLine();

                    if (input == "1")
                    {
                        Itemset itset = new Itemset();
                        Item item = new Item { Name = "수련자 갑옷" };
                        itset.UseItem(item);

                        GameCharacter character = new GameCharacter();
                        character.SetStatsChangedCallback(stats =>
                        {
                            if (stats <= 0)
                            {
                                Console.WriteLine("+");
                            }
                        });

                        character.Stats = 5;
                    }
                        if (input == "0")
                    {
                        return;
                    }
                }


            }

            static void ShopMenu()
            {
                while (true)
                {
                    Console.WriteLine("[보유 골드]");
                    Console.WriteLine("{0} G", PlayerGold);
                    Console.WriteLine();
                    Console.WriteLine("[아이템 목록]");

                    Player person1;
                    person1.Name = "- 수련자 갑옷";
                    person1.Price = 1000;
                    person1.itemInfo = "| 방어력 +5  | 수련에 도움을 주는 갑옷입니다.             |";
                    person1.PrintInfo();

                    Player person2;
                    person2.Name = "- 무쇠갑옷";
                    person2.Price = 2500;
                    person2.itemInfo = "| 방어력 +9  | 무쇠로 만들어져 튼튼한 갑옷입니다.           |";
                    person2.PrintInfo();

                    Player person3;
                    person3.Name = "- 스파르타의 갑옷";
                    person3.Price = 3500;
                    person3.itemInfo = "| 방어력 +15 | 스파르타의 전사들이 사용했다는 전설의 갑옷입니다.|";
                    person3.PrintInfo();

                    Player person4;
                    person4.Name = "- 낡은 검";
                    person4.Price = 600;
                    person4.itemInfo = "| 공격력 +2  | 쉽게 볼 수 있는 낡은 검 입니다.            |";
                    person4.PrintInfo();

                    Player person5;
                    person5.Name = "- 청동 도끼";
                    person5.Price = 1500;
                    person5.itemInfo = "| 공격력 +5  |  어디선가 사용됐던거 같은 도끼입니다.        |";
                    person5.PrintInfo();

                    Player person6;
                    person6.Name = "- 스파르타의 창";
                    person6.Price = 2000;
                    person6.itemInfo = "| 공격력 +7  | 스파르타의 전사들이 사용했다는 전설의 창입니다. |";
                    person6.PrintInfo();

                    Console.WriteLine();
                    Console.WriteLine("1. 아이템 구매");
                    Console.WriteLine("0. 나가기");
                    Console.WriteLine();
                    Console.WriteLine("원하시는 행동을 입력해주세요.");
                    Console.Write(">>");

                    string input = Console.ReadLine();

                    if (input == "1")
                    {
                        ShopMenu2();
                    }

                    if (input == "0")
                    {
                        Goback();
                        return;
                    }
                }
            }

            ////상점 구매
            static void ShopMenu2()
            {

                while (true)
                {
                    Console.WriteLine("[보유 골드]");
                    Console.WriteLine("{0} G", PlayerGold);
                    Console.WriteLine();
                    Console.WriteLine("[아이템 목록]");

                    Player person1;
                    person1.Name = "- 1 수련자 갑옷";
                    person1.Price = 1000;
                    person1.itemInfo = "| 방어력 +5  | 수련에 도움을 주는 갑옷입니다.             |";
                    person1.PrintInfo();

                    Player person2;
                    person2.Name = "- 2 무쇠갑옷";
                    person2.Price = 2500;
                    person2.itemInfo = "| 방어력 +9  | 무쇠로 만들어져 튼튼한 갑옷입니다.           |";
                    person2.PrintInfo();

                    Player person3;
                    person3.Name = "- 3 스파르타의 갑옷";
                    person3.Price = 3500;
                    person3.itemInfo = "| 방어력 +15 | 스파르타의 전사들이 사용했다는 전설의 갑옷입니다.|";
                    person3.PrintInfo();

                    Player person4;
                    person4.Name = "- 4 낡은 검";
                    person4.Price = 600;
                    person4.itemInfo = "| 공격력 +2  | 쉽게 볼 수 있는 낡은 검 입니다.            |";
                    person4.PrintInfo();

                    Player person5;
                    person5.Name = "- 5 청동 도끼";
                    person5.Price = 1500;
                    person5.itemInfo = "| 공격력 +5  |  어디선가 사용됐던거 같은 도끼입니다.        |";
                    person5.PrintInfo();

                    Player person6;
                    person6.Name = "- 6 스파르타의 창";
                    person6.Price = 2000;
                    person6.itemInfo = "| 공격력 +7  | 스파르타의 전사들이 사용했다는 전설의 창입니다. |";
                    person6.PrintInfo();

                    Console.WriteLine();
                    Console.WriteLine("0. 나가기");
                    Console.WriteLine();
                    Console.WriteLine("원하시는 행동을 입력해주세요.");
                    Console.Write(">>");

                    string input = Console.ReadLine();

                    string itemName = "Gold";

                    switch (input)
                    {
                        case "1":
                            if (PlayerGold >= 1000)
                            {
                                Console.WriteLine("구매완료");
                                PlayerGold -=1000;
                            }
                            else
                            {
                                Console.WriteLine($" {itemName}가 부족합니다.");
                            }
                            break;
                        case "2":
                            if (PlayerGold >= 2500)
                            {
                                Console.WriteLine("구매완료");
                                PlayerGold -=2500;
                            }
                            else
                            {
                                Console.WriteLine($" {itemName}가 부족합니다.");
                            }
                            break;
                        case "3":
                            if (PlayerGold >= 3500)
                            {
                                Console.WriteLine("구매완료");
                                PlayerGold -= 3500;
                            }
                            else
                            {
                                Console.WriteLine($" {itemName}가 부족합니다.");
                            }
                            break;
                        case "4":
                            if (PlayerGold >= 600)
                            {
                                Console.WriteLine("구매완료");
                                PlayerGold -= 600;
                            }
                            else
                            {
                                Console.WriteLine($" {itemName}가 부족합니다.");
                            }
                            break;
                        case "5":
                            if (PlayerGold >= 1500)
                            {
                                Console.WriteLine("구매완료");
                                PlayerGold -= 1500;
                            }
                            else
                            {
                                Console.WriteLine($" {itemName}가 부족합니다.");
                            }
                            break;
                        case "6":
                            if (PlayerGold >= 2000)
                            {
                                Console.WriteLine("구매완료");
                                PlayerGold -= 2000;
                            }
                            else
                            {
                                Console.WriteLine($" {itemName}가 부족합니다.");
                            }
                            break;
                        case "0":
                            {
                                return;
                            }
                            break;
                        default:
                            Console.WriteLine("잘못된 입력입니다.");
                            break;

                        
                    }
                }
            }
        }
    }
}
